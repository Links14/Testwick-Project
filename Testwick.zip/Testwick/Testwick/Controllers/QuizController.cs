﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Testwick.Data;
using Testwick.DTOs;
using Testwick.Services;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Testwick.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class QuizController(IQuizService quizService) : ControllerBase
    {
        private readonly IQuizService _quizService = quizService;

        //[HttpGet]
        //public async Task<IActionResult> GetAll()
        //{
        //    return Ok(await _quizService.GetAllAsync());
        //}

        [HttpGet("{id:int}")]
        public async Task<IActionResult> GetById(int id)
        {
            var quiz = await _quizService.GetByIdAsync(id);
            if (quiz is null) return NotFound();
            return Ok(quiz);
        }

        [HttpGet("admin/{adminToken:Guid}")]
        public async Task<IActionResult> GetByToken(Guid adminToken)
        {
            var quiz = await _quizService.GetByAdminTokenAsync(adminToken);
            if (quiz is null) return NotFound();
            return Ok(quiz);
        }

        [HttpPut("admin/{adminToken:Guid}")]
        public async Task<IActionResult> Update(Guid adminToken, CreateQuizDto dto)
        {
            var success = await _quizService.UpdateByAdminTokenAsync(adminToken, dto);
            if (!success) return NotFound();
            return NoContent();
        }


        [HttpPost]
        public async Task<IActionResult> Create(CreateQuizDto dto)
        {
            var created = await _quizService.CreateAsync(dto);
            return CreatedAtAction(nameof(GetById), new { id = created.Id }, created);
        }

        [HttpPut("admin/{adminToken:Guid}/AddQuestion/")]
        public async Task<IActionResult> AddQuestion(Guid adminToken, int questionId)
        {
            var updated = await _quizService.AddExistingQuestionByAdminTokenAsync(adminToken, questionId);
            return updated is null ? NotFound() : Ok(updated);
        }


        /// Made Innaccessable
        //[HttpDelete("{id}")]
        //public async Task<IActionResult> Delete(int id)
        //{
        //    var success = await _quizService.DeleteAsync(id);
        //    if (!success) return NotFound();
        //    return NoContent();
        //}
    }
}
