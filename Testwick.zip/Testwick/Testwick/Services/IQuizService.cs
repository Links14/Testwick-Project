﻿namespace Testwick.Services
{
    using Testwick.DTOs;

    public interface IQuizService
    {
        // Get
        Task<IEnumerable<QuizDto>> GetAllAsync();
        Task<QuizDto?> GetByIdAsync(int id);
        Task<QuizDto?> GetByAdminTokenAsync(Guid adminToken);        // admin landing page

        // Post
        Task<QuizCreatedDto> CreateAsync(CreateQuizDto dto);
        Task<QuizDto?> ContributeQuestionAsync(Guid contributorToken, CreateQuestionDto dto);

        // Put
        Task<bool> UpdateByAdminTokenAsync(Guid adminToken, CreateQuizDto dto);
        //Task<bool> UpdateAsync(int id, CreateQuizDto dto);
        Task<QuizDto?> AddExistingQuestionByAdminTokenAsync(Guid adminToken, int questionId);
        //Task<QuizDto?> AddExistingQuestionAsync(int quizId, int questionId);

    }
}
